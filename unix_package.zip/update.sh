#!/bin/bash
docker-compose pull
docker-compose up -d --build
echo "Cleaning up old versions to save space..."
docker system prune -af
echo "Application Successfully Updated. Head to http://localhost:3000 to access it."