#!/bin/bash
docker-compose down
echo "Application Closed."