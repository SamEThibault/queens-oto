#!/bin/bash

# Define the directories and file paths
backupDir="./backup"
localStoreDir="./local_store"
databaseFile="$localStoreDir/student.db"
picturesDir="./profile_pictures"

# Create the /backup directory if it doesn't exist
if [ ! -d "$backupDir" ]; then
    mkdir "$backupDir"
    echo "Created directory: $backupDir"
else
    echo "Directory already exists: $backupDir"
fi

# Create the /local_store directory if it doesn't exist
if [ ! -d "$localStoreDir" ]; then
    mkdir "$localStoreDir"
    echo "Created directory: $localStoreDir"
else
    echo "Directory already exists: $localStoreDir"
fi

# Create the /profile_pictures directory if it doesn't exist
if [ ! -d "$picturesDir" ]; then
    mkdir "$picturesDir"
    echo "Created directory: $picturesDir"
else
    echo "Directory already exists: $picturesDir"
fi

# Create the student.db file inside the /local_store directory
if [ ! -f "$databaseFile" ]; then
    touch "$databaseFile"
    echo "Created file: $databaseFile"
else
    echo "File already exists: $databaseFile"
fi

chmod +x start.sh update.sh stop.sh
echo "Initialization successful. To start the program, run the start script."