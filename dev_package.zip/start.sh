docker-compose up -d --build
echo "Head to http://localhost:3000 on any browser to access the application."