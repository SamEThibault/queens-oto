docker-compose down
Write-Host "Application Closed."