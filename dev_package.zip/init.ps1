# Define the directories and file paths
$backupDir = ".\backup"
$localStoreDir = ".\local_store"
$databaseFile = ".\local_store\student.db"
$picturesDir = ".\profile_pictures"

# Create the /backup directory if it doesn't exist
if (-not (Test-Path -Path $backupDir)) {
    New-Item -Path $backupDir -ItemType Directory
    Write-Host "Created directory: $backupDir"
}
else {
    Write-Host "Directory already exists: $backupDir"
}

# Create the /local_store directory if it doesn't exist
if (-not (Test-Path -Path $localStoreDir)) {
    New-Item -Path $localStoreDir -ItemType Directory
    Write-Host "Created directory: $localStoreDir"
}
else {
    Write-Host "Directory already exists: $localStoreDir"
}

# Create the /profile_pictures directory if it doesn't exist
if (-not (Test-Path -Path $picturesDir)) {
    New-Item -Path $picturesDir -ItemType Directory
    Write-Host "Created directory: $picturesDir"
}
else {
    Write-Host "Directory already exists: $picturesDir"
}

# Create the student.db file inside the /local_store directory
if (-not (Test-Path -Path $databaseFile)) {
    New-Item -Path $databaseFile -ItemType File
    Write-Host "Created file: $databaseFile"
}
else {
    Write-Host "File already exists: $databaseFile"
}

Write-Host "Initialization successful. To start the program, run the start script."