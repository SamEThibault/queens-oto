docker-compose up -d --build
Write-Host "Head to http://localhost:3000 on any browser to access the application."