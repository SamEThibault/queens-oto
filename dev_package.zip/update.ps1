docker-compose pull
docker-compose up -d --build
Write-Host "Cleaning up old versions to save space..."
docker system prune -af
Write-Host "Application Successfully Updated. Head to http://localhost:3000 to access it."